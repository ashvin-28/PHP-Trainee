<?php
session_start();
if (!isset($_SESSION["email"])) {
   header("Location:/PHP-Trainee/AdminLTE/loginPage.php");
}
include "connection.php";
include "../header.php";
include "../sidebar.php";
?>
    
   
<!-- Button to trigger modal -->
<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#adminPopupForm">
    Open Form
</button>
<!-- AdminLTE 4 Popup Form -->
<div class="modal fade" id="adminPopupForm" tabindex="-1" aria-labelledby="adminPopupFormLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg"> <!-- modal-lg makes it wider -->
        <div class="modal-content">
            
            <!-- Modal Header -->
            <div class="modal-header">
                <h5 class="modal-title" id="adminPopupFormLabel">Create New Entry</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            
            <!-- Modal Body (Form) -->
            <div class="modal-body">
               <form id="insertForm" class="m-4" method="POST" enctype="multipart/form-data" autocomplete="off">
        <div class="card-body">
            <input type="hidden" name="emp_id" id="emp_id">
            <div class="form-group">
                <label for="">First Name: </label>
                <input type="text" class="form-control" name="firstName" id="firstName" value="">
                <span class="error text-danger" id="firstNameError"></span><br><br>
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Last Name</label>
                <input type="text" class="form-control" name="lastName" id="lastName" value="">
                <span class="error text-danger" id="lastNameError"></span><br><br>

            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Email address</label>
                <input type="email" id="email" class="form-control" name="email" autocomplete="off" value="">
                <span class="error text-danger" id="emailError"></span><br><br>
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Password</label>
                <input type="password" id="password" class="form-control" name="password" autocomplete="new-password" value="">
                <span class="error text-danger" id="passwordError"></span><br><br>
            </div>
            <div class="form-group">Confirm Password</label>
                <input type="password" id="confirmPassword" class="form-control" name="confirmPassword" value="">
                <span class="error text-danger" id="confirmPasswordError"></span><br><br>
            </div>

            <div class="form-group">
                <label for="exampleInputFile">Photo Input</label>
                <div class="input-group">
                    <div class="custom-file">
                        <input type="file" id="image" class="custom-file-input" name="image">
                        <span class="error text-danger" id="fileError"></span><br><br>
                    </div>

                </div>
            </div>
            <div class="form-group">
                <label for="exampleTextarea">Address</label>
                <textarea class="form-control" id="address" rows="3" placeholder="Enter ..." name="address"></textarea>
                <span class="error text-danger" id="addressError"></span><br><br>
            </div>
            <div class="form-group">Phone Number</label>
                <input type="number" id="phoneNumber" class="form-control" name="phoneNumber" value="">
                <span class="error text-danger" id="phoneNumberError"></span><br><br>
            </div>


            <div class="form-group">
                <label>Gender:</label>
                <div class="custom-control custom-radio">
                    <input class="custom-control-input" type="radio" name="gender" value="Male">
                    <label for="customRadio1" class="custom-control-label">Male</label>
                </div>

                <div class="custom-control custom-radio">
                    <input class="custom-control-input" type="radio" name="gender" value="Female">
                    <label for="customRadio1" class="custom-control-label">Female</label>
                </div>
                <span class="error text-danger" id="genderError"></span><br><br>


            </div>

            <div class="form-group">
                <label>Hobbies:</label>

                <div class="custom-control custom-checkbox">
                    <input class="hobbies custom-control-input" type="checkbox" name="hobbies[]" value="Playing" <?php echo (in_array('Playing', $oldData['hobbies'] ?? [])) ? 'checked' : ''; ?>>
                    <label for="customCheckbox1" class="custom-control-label">Playing</label>
                </div>
                <div class="custom-control custom-checkbox">
                    <input class="hobbies custom-control-input" type="checkbox" name="hobbies[]" value="Reading" <?php echo (in_array('Reading', $oldData['hobbies'] ?? [])) ? 'checked' : ''; ?>>
                    <label for="customCheckbox1" class="custom-control-label">Reading</label>
                </div>
                <span class="error text-danger" id="hobbiesError"></span><br><br>

            </div>



            <div class="form-group">
                <label>Select</label>
                <select class="form-control" id="countryName" name="countryName">
                    <option value="">Select Country</option>
                    <option value="India">India</option>
                    <option value="USA">USA</option>
                    <option value="Australia">Australia</option>
                </select>
                <span class="error text-danger" id="countryError"></span><br><br>

            </div>



            <div class="card-footer m-2">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
            </div>
            
          
        </div>
    </div>
</div>

<div class="app-wrapper" id="tableContainer">
  <div class="card ">
    <div class="card-header m-3">
      <h3 class="card-title">Employee Table</h3>

    </div>
   
  <?php
    if (isset($_SESSION['success_message'])) {
    ?>
      <div class="alert alert-success alert-dismissible fade show m-2" role="alert">
        <strong><?php echo $_SESSION['success_message'] ?></strong>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    <?php
    }
    unset($_SESSION['success_message']);
    ?>
    
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- /.card-header -->
    <div class="card-body  table-responsive">
      <table id="example1" class="table table-sm display responsive table-bordered table-striped ">
        <thead>
          <tr>
            <th>#</th>
            <th>firstName</th>
            <th>lastName</th>
            <th>Email</th>
            <th>Address</th>
            <th>Phone Number</th>
            <th>Gender</th>
            <th>Hobbies</th>
            <th>Country</th>
            <th>Image</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php
           
           
           $sql = "select * from ajaxCrud";
           
           $result = mysqli_query($conn, $sql);
           $row_count = 1;
           
           $numRows = mysqli_num_rows($result);
           if ($numRows > 0) {
             while ($row = mysqli_fetch_assoc($result)) {
               ?>
               <tr data-id="1"  id="row_<?php echo $row['emp_id']; ?>">
                <td class="row-data" data-name="emp_id"><?php echo $row_count++; ?></td>
                <td class="row-data" data-name="firstName"><?php echo $row["firstName"]; ?></td>
                <td class="row-data" data-name="lastName"><?php echo $row["lastName"]; ?></td>
                <td class="row-data" data-name="email"><?php echo $row["email"]; ?></td>
                <td class="row-data" data-name="address"><?php echo $row["address"]; ?></td>
                <td class="row-data" data-name="phonenumber"><?php echo $row["phonenumber"]; ?></td>
                <td class="row-data" data-name="gender"><?php echo $row["gender"]; ?></td>
                <td class="row-data" data-name="hobbies"><?php echo $row["hobbies"]; ?></td>
                <td class="row-data" data-name="country"><?php echo $row["country"]; ?></td>

                <td class="row-data" data-name="name">
                
                    <img src="/PHP-Trainee/AdminLTE/ajaxCrud/<?php echo $row["image"]; ?>" alt="" width="50px" hight="50px">
                
   
                </td>
              
          
             <!-- Table row me -->
<td >
    <button class="btn btn-sm btn-primary" 
    onclick="window.location.href='/PHP-Trainee/AdminLTE/ajaxCrud/insertForm.php?edit_id=<?php echo $row['emp_id']; ?>'">
    Edit
</button>
    <button class="btn btn-sm btn-danger" onclick="deleteData(<?php echo $row['emp_id']; ?>)">Delete</button>
</td>
              

          </tr>
      <?php
              }
            } else {
              echo "No data found";
            }
      ?>
      <!-- Add more rows here -->
        </tbody>
      </table>
    </div>
    <!-- /.card-body -->
  </div>
  <!-- /.card -->

</div>
<script src="/PHP-Trainee/AdminLTE/ajaxCrud/crud.js"></script>
<?php
include "../footer.php";
